<?php
//--index.php
echo "<h1>Backend page </h1><hr>";
echo "<a href='../index.php'> BACK </a>;

?>